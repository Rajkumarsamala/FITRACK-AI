/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  safelist: [
    'container',
    'max-w-[1200px]',
    'grid',
    'lg:grid-cols-12',
    'gap-8',
    'p-6',
    'lg:p-8',
    'space-y-6',
    'lg:space-y-8',
    'text-5xl',
    'lg:text-6xl',
    'text-2xl',
    'lg:text-3xl',
    'grid-cols-1',
    'md:grid-cols-2',
    'lg:grid-cols-3',
    'lg:col-span-8',
    'lg:col-span-4',
    'lg:col-start-3',
    'items-stretch',
    'content-start',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#faf5ff',
          100: '#f3e8ff',
          200: '#e9d5ff',
          300: '#d8b4fe',
          400: '#c084fc',
          500: '#a855f7',
          600: '#9333ea',
          700: '#7c3aed',
          800: '#6b21a8',
          900: '#581c87',
        },
        dark: {
          100: '#1e1e2e',
          200: '#181825',
          300: '#11111b',
          400: '#0a0a14',
        }
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'hero-gradient': 'linear-gradient(135deg, #0a0a14 0%, #1a1a2e 50%, #16213e 100%)',
      }
    },
  },
  plugins: [],
}
