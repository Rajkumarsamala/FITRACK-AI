import { useNavigate } from 'react-router-dom';
import { Scale, Flame, Target, TrendingUp, Dumbbell, Calendar, Lightbulb } from 'lucide-react';
import { Layout } from '../components/shared/Layout';
import { Card, StatCard } from '../components/shared/Card';
import { Button } from '../components/shared/Button';
import { ProgressRing } from '../components/shared/ProgressRing';
import { GoalToggle } from '../components/shared/GoalToggle';
import { BackLink } from '../components/shared/BackLink';
import { useGoal } from '../contexts/GoalContext';
import { useUser } from '../contexts/UserContext';
import { calculateBMR, calculateTDEE, calculateGoalCalories, calculateMacros } from '../services/calculator';
import { getRandomTip } from '../data/tips';

export function Dashboard() {
  const navigate = useNavigate();
  const { currentGoal } = useGoal();
  const { profile, metrics, dailyLogs } = useUser();

  if (!profile) {
    navigate('/onboarding');
    return null;
  }

  const bmr = calculateBMR(profile.currentWeight, profile.height, profile.age, profile.gender);
  const tdee = calculateTDEE(bmr, profile.activityLevel);
  const goalCalories = calculateGoalCalories(tdee, currentGoal);
  const macros = calculateMacros(goalCalories, currentGoal, profile.currentWeight);
  const tip = getRandomTip(currentGoal);

  const today = new Date().toISOString().split('T')[0];
  const todayLog = dailyLogs.find(log => log.date === today);

  const weightProgress = metrics?.percentageComplete || 0;
  const weightChange = metrics?.weightChange || 0;
  const isGaining = currentGoal === 'gain-weight';

  return (
    <Layout>
      <header className="page-header mb-12">
        <BackLink />
        <div className="flex-1 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <h1 className="text-page-title text-white mb-2">Welcome back, {profile.name}!</h1>
            <p className="text-body text-gray-400">Track your progress and stay on top of your goals</p>
          </div>
          <GoalToggle />
        </div>
      </header>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mb-12">
        <StatCard
          title="Current Weight"
          value={`${profile.currentWeight} kg`}
          subtitle={`${weightChange > 0 ? '+' : ''}${weightChange.toFixed(1)} kg`}
          trend={isGaining ? (weightChange > 0 ? 'up' : 'down') : (weightChange < 0 ? 'up' : 'down')}
          icon={<Scale className="w-6 h-6 text-white" />}
          color="purple"
        />
        <StatCard
          title="Daily Calories"
          value={goalCalories.toLocaleString()}
          subtitle={isGaining ? 'Surplus target' : 'Deficit target'}
          icon={<Flame className="w-6 h-6 text-white" />}
          color={isGaining ? 'green' : 'orange'}
        />
        <StatCard
          title="Target Weight"
          value={`${profile.targetWeight} kg`}
          subtitle={`${Math.abs(profile.targetWeight - profile.currentWeight).toFixed(1)} kg to go`}
          icon={<Target className="w-6 h-6 text-white" />}
          color="blue"
        />
        <StatCard
          title="Workout Streak"
          value={metrics?.streak || 0}
          subtitle="days in a row"
          icon={<Dumbbell className="w-6 h-6 text-white" />}
          color="purple"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-12">
        <Card className="lg:col-span-2 p-8">
          <h2 className="text-section-title text-white mb-8 flex items-center gap-3">
            <TrendingUp className="w-6 h-6 text-purple-400" />
            Your Progress
          </h2>
          <div className="flex flex-col md:flex-row items-center justify-around py-8 gap-8">
            <div className="text-center">
              <ProgressRing progress={weightProgress} size={140}>
                <div>
                  <div className="text-3xl font-bold text-white">{Math.round(weightProgress)}%</div>
                  <div className="text-label text-gray-400">Complete</div>
                </div>
              </ProgressRing>
            </div>
            <div className="space-y-6">
              <div>
                <div className="text-label text-gray-400 mb-1">Start Weight</div>
                <div className="text-2xl font-bold text-white">{metrics?.startWeight || profile.currentWeight} kg</div>
              </div>
              <div>
                <div className="text-label text-gray-400 mb-1">Current Weight</div>
                <div className="text-2xl font-bold text-white">{metrics?.currentWeight || profile.currentWeight} kg</div>
              </div>
              <div>
                <div className="text-label text-gray-400 mb-1">Goal Weight</div>
                <div className="text-2xl font-bold text-purple-400">{profile.targetWeight} kg</div>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-8">
          <h2 className="text-section-title text-white mb-8 flex items-center gap-3">
            <Flame className={`w-6 h-6 ${isGaining ? 'text-green-400' : 'text-orange-400'}`} />
            Daily Macros
          </h2>
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-body text-gray-400 font-medium">Protein</span>
                <span className="text-body text-white font-semibold">{macros.protein}g</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: '100%' }} />
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-body text-gray-400 font-medium">Carbs</span>
                <span className="text-body text-white font-semibold">{macros.carbs}g</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2">
                <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '100%' }} />
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-body text-gray-400 font-medium">Fats</span>
                <span className="text-body text-white font-semibold">{macros.fats}g</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2">
                <div className="bg-pink-500 h-2 rounded-full" style={{ width: '100%' }} />
              </div>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        <Card className={`border-l-4 p-8 ${isGaining ? 'border-l-green-500' : 'border-l-orange-500'}`}>
          <div className="flex items-start gap-5">
            <div className={`w-14 h-14 rounded-xl ${isGaining ? 'bg-green-500/20' : 'bg-orange-500/20'} flex items-center justify-center flex-shrink-0`}>
              <Lightbulb className={`w-7 h-7 ${isGaining ? 'text-green-400' : 'text-orange-400'}`} />
            </div>
            <div>
              <div className="text-label text-gray-500 uppercase tracking-widest font-semibold mb-2">{tip.category}</div>
              <h3 className="text-card-title text-white mb-3">{tip.title}</h3>
              <p className="text-body text-gray-400 leading-relaxed">{tip.content}</p>
            </div>
          </div>
        </Card>

        <Card className="p-8">
          <h3 className="text-card-title text-white mb-6 flex items-center gap-3">
            <Calendar className="w-6 h-6 text-purple-400" />
            Today's Log
          </h3>
          {todayLog ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-body text-gray-400">Calories Consumed</span>
                <span className="text-body text-white font-semibold">{todayLog.caloriesConsumed}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-body text-gray-400">Workout</span>
                <span className={`text-body font-semibold ${todayLog.workoutCompleted ? 'text-green-400' : 'text-gray-500'}`}>
                  {todayLog.workoutCompleted ? 'Completed ✓' : 'Not yet'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-body text-gray-400">Water Intake</span>
                <span className="text-body text-white font-semibold">{todayLog.waterIntake}L</span>
              </div>
            </div>
          ) : (
            <div className="text-center py-6">
              <p className="text-body text-gray-400 mb-5">No log for today yet</p>
              <Button size="sm" onClick={() => navigate('/progress')}>
                Log Today
              </Button>
            </div>
          )}
        </Card>
      </div>

      <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
        <Button fullWidth onClick={() => navigate('/nutrition')} className="py-4">
          <Flame className="w-5 h-5" />
          View Meal Plans
        </Button>
        <Button fullWidth variant="secondary" onClick={() => navigate('/workouts')} className="py-4">
          <Dumbbell className="w-5 h-5" />
          Start Workout
        </Button>
        <Button fullWidth variant="outline" onClick={() => navigate('/tips')} className="py-4">
          <Lightbulb className="w-5 h-5" />
          Get AI Tips
        </Button>
      </div>
    </Layout>
  );
}
