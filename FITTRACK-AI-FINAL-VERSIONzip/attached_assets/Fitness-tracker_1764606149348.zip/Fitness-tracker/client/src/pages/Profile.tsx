import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Scale, Ruler, Activity, Target, Save, LogOut, Trash2 } from 'lucide-react';
import { Layout } from '../components/shared/Layout';
import { Card } from '../components/shared/Card';
import { Button } from '../components/shared/Button';
import { GoalToggle } from '../components/shared/GoalToggle';
import { useGoal } from '../contexts/GoalContext';
import { useUser } from '../contexts/UserContext';
import { calculateBMI, getBMICategory, calculateBMR, calculateTDEE } from '../services/calculator';
import type { ActivityLevel } from '../types';

const activityLevels: { value: ActivityLevel; label: string }[] = [
  { value: 'sedentary', label: 'Sedentary' },
  { value: 'light', label: 'Lightly Active' },
  { value: 'moderate', label: 'Moderately Active' },
  { value: 'active', label: 'Active' },
  { value: 'very-active', label: 'Very Active' },
];

export function Profile() {
  const navigate = useNavigate();
  const { currentGoal } = useGoal();
  const { profile, updateProfile, metrics } = useUser();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: profile?.name || '',
    age: profile?.age?.toString() || '',
    height: profile?.height?.toString() || '',
    currentWeight: profile?.currentWeight?.toString() || '',
    targetWeight: profile?.targetWeight?.toString() || '',
    activityLevel: profile?.activityLevel || 'moderate',
  });

  if (!profile) {
    navigate('/onboarding');
    return null;
  }

  const bmi = calculateBMI(profile.currentWeight, profile.height);
  const bmiCategory = getBMICategory(bmi);
  const bmr = calculateBMR(profile.currentWeight, profile.height, profile.age, profile.gender);
  const tdee = calculateTDEE(bmr, profile.activityLevel);

  const isGaining = currentGoal === 'gain-weight';

  const handleSave = () => {
    updateProfile({
      name: formData.name,
      age: parseInt(formData.age),
      height: parseFloat(formData.height),
      currentWeight: parseFloat(formData.currentWeight),
      targetWeight: parseFloat(formData.targetWeight),
      activityLevel: formData.activityLevel as ActivityLevel,
    });
    setIsEditing(false);
  };

  const handleReset = () => {
    if (confirm('Are you sure you want to reset all data? This cannot be undone.')) {
      localStorage.clear();
      navigate('/');
      window.location.reload();
    }
  };

  return (
    <Layout>
      <div className="mb-12 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div>
          <h1 className="text-page-title text-white mb-1">Your Profile</h1>
          <p className="text-body text-gray-400">Manage your personal information and settings</p>
        </div>
        <GoalToggle />
      </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-12">
        <Card className="lg:col-span-2 p-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-section-title text-white flex items-center gap-3">
              <User className="w-5 h-5 text-purple-400" />
              Personal Information
            </h2>
            {!isEditing ? (
              <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                Edit
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button size="sm" variant="ghost" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button size="sm" onClick={handleSave}>
                  <Save className="w-4 h-4" />
                  Save
                </Button>
              </div>
            )}
          </div>

          {isEditing ? (
            <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Age</label>
                <input
                  type="number"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Height (cm)</label>
                <input
                  type="number"
                  value={formData.height}
                  onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Current Weight (kg)</label>
                <input
                  type="number"
                  value={formData.currentWeight}
                  onChange={(e) => setFormData({ ...formData, currentWeight: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Target Weight (kg)</label>
                <input
                  type="number"
                  value={formData.targetWeight}
                  onChange={(e) => setFormData({ ...formData, targetWeight: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Activity Level</label>
                <select
                  value={formData.activityLevel}
                  onChange={(e) => setFormData({ ...formData, activityLevel: e.target.value as ActivityLevel })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:outline-none"
                >
                  {activityLevels.map((level) => (
                    <option key={level.value} value={level.value} className="bg-dark-200">
                      {level.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <User className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Name</div>
                  <div className="text-white font-semibold">{profile.name}</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                  <Ruler className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Height</div>
                  <div className="text-white font-semibold">{profile.height} cm</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-orange-500/20 flex items-center justify-center">
                  <Scale className="w-6 h-6 text-orange-400" />
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Current Weight</div>
                  <div className="text-white font-semibold">{profile.currentWeight} kg</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl ${isGaining ? 'bg-green-500/20' : 'bg-orange-500/20'} flex items-center justify-center`}>
                  <Target className={`w-6 h-6 ${isGaining ? 'text-green-400' : 'text-orange-400'}`} />
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Target Weight</div>
                  <div className={`font-semibold ${isGaining ? 'text-green-400' : 'text-orange-400'}`}>
                    {profile.targetWeight} kg
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-pink-500/20 flex items-center justify-center">
                  <Activity className="w-6 h-6 text-pink-400" />
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Activity Level</div>
                  <div className="text-white font-semibold capitalize">{profile.activityLevel.replace('-', ' ')}</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                  <User className="w-6 h-6 text-yellow-400" />
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Age & Gender</div>
                  <div className="text-white font-semibold">{profile.age} years, {profile.gender}</div>
                </div>
              </div>
            </div>
          )}
        </Card>

        <div className="space-y-6">
          <Card>
            <h3 className="text-lg font-bold text-white mb-4">Body Stats</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">BMI</span>
                <div className="text-right">
                  <span className="text-white font-bold">{bmi}</span>
                  <span className={`ml-2 text-sm ${
                    bmiCategory === 'Normal' ? 'text-green-400' :
                    bmiCategory === 'Underweight' ? 'text-yellow-400' :
                    'text-orange-400'
                  }`}>
                    ({bmiCategory})
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">BMR</span>
                <span className="text-white font-bold">{bmr} cal/day</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">TDEE</span>
                <span className="text-white font-bold">{tdee} cal/day</span>
              </div>
            </div>
          </Card>

          <Card>
            <h3 className="text-lg font-bold text-white mb-4">Journey Stats</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Workouts Completed</span>
                <span className="text-white font-bold">{metrics?.workoutsCompleted || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Current Streak</span>
                <span className="text-white font-bold">{metrics?.streak || 0} days</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Progress</span>
                <span className="text-purple-400 font-bold">{Math.round(metrics?.percentageComplete || 0)}%</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <Card className="border border-red-500/30 bg-red-500/5">
        <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
          <Trash2 className="w-5 h-5 text-red-400" />
          Danger Zone
        </h3>
        <p className="text-gray-400 mb-4">Reset all your data and start fresh. This action cannot be undone.</p>
        <Button variant="outline" onClick={handleReset} className="border-red-500 text-red-400 hover:bg-red-500/10">
          <LogOut className="w-4 h-4" />
          Reset All Data
        </Button>
      </Card>
    </Layout>
  );
}
