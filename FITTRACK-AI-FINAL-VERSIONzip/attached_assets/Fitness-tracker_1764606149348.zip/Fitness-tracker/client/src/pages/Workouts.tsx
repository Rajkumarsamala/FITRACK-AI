import { useState } from 'react';
import { Dumbbell, Clock, Flame, Play, ChevronRight, Trophy, Target } from 'lucide-react';
import { Layout } from '../components/shared/Layout';
import { Card } from '../components/shared/Card';
import { Button } from '../components/shared/Button';
import { GoalToggle } from '../components/shared/GoalToggle';
import { BackLink } from '../components/shared/BackLink';
import { useGoal } from '../contexts/GoalContext';
import { getWorkoutsByGoal } from '../data/workouts';
import type { WorkoutPlan } from '../types';

export function Workouts() {
  const { currentGoal } = useGoal();
  const [selectedWorkout, setSelectedWorkout] = useState<WorkoutPlan | null>(null);
  const [currentExercise, setCurrentExercise] = useState(0);
  const [isWorkoutActive, setIsWorkoutActive] = useState(false);

  const workouts = getWorkoutsByGoal(currentGoal);
  const isGaining = currentGoal === 'gain-weight';

  const startWorkout = (workout: WorkoutPlan) => {
    setSelectedWorkout(workout);
    setCurrentExercise(0);
    setIsWorkoutActive(true);
  };

  const nextExercise = () => {
    if (selectedWorkout && currentExercise < selectedWorkout.exercises.length - 1) {
      setCurrentExercise(currentExercise + 1);
    } else {
      setIsWorkoutActive(false);
      setSelectedWorkout(null);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-400 bg-green-400/20';
      case 'intermediate': return 'text-yellow-400 bg-yellow-400/20';
      case 'advanced': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  if (isWorkoutActive && selectedWorkout) {
    const exercise = selectedWorkout.exercises[currentExercise];
    const progress = ((currentExercise + 1) / selectedWorkout.exercises.length) * 100;

    return (
      <Layout>
        <div className="max-w-2xl mx-auto">
          <div className="page-header mb-6">
            <BackLink />
            <div className="flex-1 flex items-center justify-between">
              <h1 className="text-page-title text-white m-0">{selectedWorkout.name}</h1>
              <span className="text-gray-400">
                {currentExercise + 1} / {selectedWorkout.exercises.length}
              </span>
            </div>
          </div>

          <div className="w-full bg-white/10 rounded-full h-2 mb-6">
            <div
              className="bg-purple-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>

          <Card className="text-center mb-6">
            <div className="w-24 h-24 rounded-full bg-purple-500/20 flex items-center justify-center mx-auto mb-6">
              <Dumbbell className="w-12 h-12 text-purple-400" />
            </div>
            <h3 className="text-section-title text-white mb-2">{exercise.name}</h3>
            <div className="flex items-center justify-center gap-4 text-gray-400 text-body mb-6">
              <span>{exercise.sets} sets</span>
              <span>•</span>
              <span>{exercise.reps}</span>
              <span>•</span>
              <span>{exercise.restTime}s rest</span>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-white/5 rounded-xl p-4">
                <div className="text-2xl font-bold text-white">{exercise.sets}</div>
                <div className="text-gray-400 text-sm">Sets</div>
              </div>
              <div className="bg-white/5 rounded-xl p-4">
                <div className="text-2xl font-bold text-white">{exercise.reps}</div>
                <div className="text-gray-400 text-sm">Reps/Duration</div>
              </div>
            </div>
          </Card>

          <div className="flex gap-4">
            <Button
              variant="ghost"
              onClick={() => {
                setIsWorkoutActive(false);
                setSelectedWorkout(null);
              }}
              className="flex-1"
            >
              Exit
            </Button>
            <Button onClick={nextExercise} className="flex-1">
              {currentExercise < selectedWorkout.exercises.length - 1 ? 'Next Exercise' : 'Finish Workout'}
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="mb-12 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div>
          <h1 className="text-page-title text-white mb-1">Workout Plans</h1>
          <p className="text-body text-gray-400">
            {isGaining ? 'Strength training for muscle building' : 'Fat-burning workouts for weight loss'}
          </p>
        </div>
        <GoalToggle />
      </div>

      <div className="grid md:grid-cols-2 gap-6 lg:gap-8 mb-12">
        <Card className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-xl ${isGaining ? 'bg-green-500/20' : 'bg-orange-500/20'} flex items-center justify-center`}>
            <Target className={`w-7 h-7 ${isGaining ? 'text-green-400' : 'text-orange-400'}`} />
          </div>
          <div>
            <div className="text-gray-400 text-sm">Focus</div>
            <div className="text-xl font-bold text-white">
              {isGaining ? 'Muscle Building' : 'Fat Burning'}
            </div>
          </div>
        </Card>
        <Card className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-purple-500/20 flex items-center justify-center">
            <Trophy className="w-7 h-7 text-purple-400" />
          </div>
          <div>
            <div className="text-gray-400 text-sm">Available Plans</div>
            <div className="text-xl font-bold text-white">{workouts.length} workouts</div>
          </div>
        </Card>
      </div>

      <div className="space-y-4">
        {workouts.map((workout) => (
          <Card key={workout.id} className="hover:border-purple-500/50 transition-all">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 rounded-xl ${isGaining ? 'bg-green-500/20' : 'bg-orange-500/20'} flex items-center justify-center flex-shrink-0`}>
                  <Dumbbell className={`w-7 h-7 ${isGaining ? 'text-green-400' : 'text-orange-400'}`} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-1">{workout.name}</h3>
                  <p className="text-gray-400 mb-2">{workout.description}</p>
                  <div className="flex flex-wrap items-center gap-3 text-sm">
                    <span className={`px-2 py-1 rounded-full ${getDifficultyColor(workout.difficulty)}`}>
                      {workout.difficulty}
                    </span>
                    <span className="flex items-center gap-1 text-gray-400">
                      <Clock className="w-4 h-4" />
                      {workout.duration} min
                    </span>
                    <span className="flex items-center gap-1 text-gray-400">
                      <Flame className="w-4 h-4" />
                      {workout.exercises.length} exercises
                    </span>
                  </div>
                </div>
              </div>
              <Button onClick={() => startWorkout(workout)} className="md:flex-shrink-0">
                <Play className="w-4 h-4" />
                Start
              </Button>
            </div>

            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="text-sm text-gray-400 mb-2">Exercises:</div>
              <div className="flex flex-wrap gap-2">
                {workout.exercises.map((exercise) => (
                  <span key={exercise.id} className="px-3 py-1 bg-white/5 rounded-full text-sm text-gray-300">
                    {exercise.name}
                  </span>
                ))}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </Layout>
  );
}
