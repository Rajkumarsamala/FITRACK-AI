import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle } from 'lucide-react';
import { Layout } from '../components/shared/Layout';
import { Card } from '../components/shared/Card';
import { Button } from '../components/shared/Button';
import { BackLink } from '../components/shared/BackLink';
import { useGoal } from '../contexts/GoalContext';
import { useUser } from '../contexts/UserContext';
import { calculateBMI, calculateBMR, calculateTDEE } from '../services/calculator';
import type { UserProfile, ActivityLevel } from '../types';

const activityLevels: { value: ActivityLevel; label: string; description: string }[] = [
  { value: 'sedentary', label: 'Sedentary', description: 'Little or no exercise' },
  { value: 'light', label: 'Lightly Active', description: 'Light exercise 1-3 days/week' },
  { value: 'moderate', label: 'Moderately Active', description: 'Moderate exercise 3-5 days/week' },
  { value: 'active', label: 'Active', description: 'Hard exercise 6-7 days/week' },
  { value: 'very-active', label: 'Very Active', description: 'Very hard exercise daily' },
];

interface FormData {
  name: string;
  age: string;
  gender: 'male' | 'female';
  height: string;
  currentWeight: string;
  targetWeight: string;
  activityLevel: ActivityLevel;
}

interface FormErrors {
  name?: string;
  age?: string;
  height?: string;
  currentWeight?: string;
  targetWeight?: string;
}

export function OnboardingSinglePage() {
  const navigate = useNavigate();
  const { currentGoal } = useGoal();
  const { setProfile } = useUser();
  const [formData, setFormData] = useState<FormData>({
    name: '',
    age: '',
    gender: 'male',
    height: '',
    currentWeight: '',
    targetWeight: '',
    activityLevel: 'moderate',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    const age = parseInt(formData.age);
    if (!formData.age) {
      newErrors.age = 'Age is required';
    } else if (isNaN(age) || age < 13 || age > 120) {
      newErrors.age = 'Age must be between 13 and 120';
    }

    const height = parseFloat(formData.height);
    if (!formData.height) {
      newErrors.height = 'Height is required';
    } else if (isNaN(height) || height < 100 || height > 250) {
      newErrors.height = 'Height must be between 100 and 250 cm';
    }

    const currentWeight = parseFloat(formData.currentWeight);
    if (!formData.currentWeight) {
      newErrors.currentWeight = 'Current weight is required';
    } else if (isNaN(currentWeight) || currentWeight < 30 || currentWeight > 300) {
      newErrors.currentWeight = 'Current weight must be between 30 and 300 kg';
    }

    const targetWeight = parseFloat(formData.targetWeight);
    if (!formData.targetWeight) {
      newErrors.targetWeight = 'Target weight is required';
    } else if (isNaN(targetWeight) || targetWeight < 30 || targetWeight > 300) {
      newErrors.targetWeight = 'Target weight must be between 30 and 300 kg';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const profile: UserProfile = {
        id: `user-${Date.now()}`,
        name: formData.name,
        email: '',
        age: parseInt(formData.age),
        gender: formData.gender,
        height: parseFloat(formData.height),
        currentWeight: parseFloat(formData.currentWeight),
        targetWeight: parseFloat(formData.targetWeight),
        activityLevel: formData.activityLevel,
        goal: currentGoal,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setProfile(profile);
      navigate('/dashboard');
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentWeight = parseFloat(formData.currentWeight) || 0;
  const height = parseFloat(formData.height) || 0;
  const bmi = currentWeight && height ? calculateBMI(currentWeight, height) : 0;
  const bmr = currentWeight && height ? calculateBMR(currentWeight, height, parseInt(formData.age) || 25, formData.gender) : 0;
  const tdee = bmr ? calculateTDEE(bmr, formData.activityLevel) : 0;

  const InputField = ({ label, name, type = 'text', placeholder, required = true }: any) => (
    <div>
      <label className="block text-label text-gray-400 mb-2 font-medium">
        {label} {required && <span className="text-red-400">*</span>}
      </label>
      <input
        type={type}
        name={name}
        value={formData[name as keyof FormData]}
        onChange={(e) => {
          setFormData({ ...formData, [name]: e.target.value });
          if (errors[name as keyof FormErrors]) {
            setErrors({ ...errors, [name]: undefined });
          }
        }}
        placeholder={placeholder}
        className={`w-full bg-white/5 border ${errors[name as keyof FormErrors] ? 'border-red-500/50' : 'border-white/10'} rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none transition-colors`}
      />
      {errors[name as keyof FormErrors] && (
        <div className="flex items-center gap-2 mt-2 text-red-400 text-sm">
          <AlertCircle className="w-4 h-4" />
          <span>{errors[name as keyof FormErrors]}</span>
        </div>
      )}
    </div>
  );

  return (
    <Layout>
      <header className="page-header flex items-center gap-6 mb-10 lg:mb-12">
        <BackLink fallback="/" />
        <h1 className="text-5xl lg:text-6xl leading-tight font-bold text-white m-0">Set Up Your Profile</h1>
      </header>

      <form onSubmit={handleSubmit} className="grid gap-6 lg:gap-8 lg:grid-cols-12 pb-24 lg:pb-0">
        {/* Left column: Main fields (8 cols) */}
        <section className="lg:col-span-8 space-y-6 lg:space-y-8">
          {/* Basic Info Card */}
          <Card className="p-6 lg:p-8 rounded-2xl">
            <h3 className="text-2xl lg:text-3xl leading-snug font-bold text-white mb-6 m-0">Basic Information</h3>

            <div className="space-y-6">
              <InputField label="Full Name" name="name" placeholder="Enter your name" />

              <div className="grid gap-4 lg:grid-cols-2">
                <InputField label="Age" name="age" type="number" placeholder="Enter your age" />
                <div>
                  <label className="block text-label text-gray-400 mb-2 font-medium">Gender *</label>
                  <div className="grid grid-cols-2 gap-3">
                    {(['male', 'female'] as const).map((gender) => (
                      <button
                        key={gender}
                        type="button"
                        onClick={() => setFormData({ ...formData, gender })}
                        className={`py-3 rounded-xl border transition-all text-body font-medium ${
                          formData.gender === gender
                            ? 'bg-purple-500/20 border-purple-500 text-purple-400'
                            : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/30'
                        }`}
                      >
                        {gender.charAt(0).toUpperCase() + gender.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Physical Metrics Card */}
          <Card className="p-6 lg:p-8 rounded-2xl">
            <h3 className="text-2xl lg:text-3xl leading-snug font-bold text-white mb-6 m-0">Physical Metrics</h3>

            <div className="space-y-6">
              <InputField label="Height (cm)" name="height" type="number" placeholder="Enter your height" />

              <div className="grid gap-4 lg:grid-cols-2">
                <InputField label="Current Weight (kg)" name="currentWeight" type="number" placeholder="Enter current weight" />
                <InputField label="Target Weight (kg)" name="targetWeight" type="number" placeholder="Enter target weight" />
              </div>
            </div>
          </Card>

          {/* Activity Level Card */}
          <Card className="p-6 lg:p-8 rounded-2xl">
            <h3 className="text-2xl lg:text-3xl leading-snug font-bold text-white mb-6 m-0">Activity Level</h3>

            <div className="space-y-3">
              {activityLevels.map((level) => (
                <button
                  key={level.value}
                  type="button"
                  onClick={() => setFormData({ ...formData, activityLevel: level.value })}
                  className={`w-full p-4 rounded-xl border transition-all text-left ${
                    formData.activityLevel === level.value
                      ? 'bg-purple-500/20 border-purple-500'
                      : 'bg-white/5 border-white/10 hover:border-white/30'
                  }`}
                >
                  <div className="font-semibold text-white text-body">{level.label}</div>
                  <div className="text-label text-gray-400">{level.description}</div>
                </button>
              ))}
            </div>
          </Card>
        </section>

        {/* Right column: Summary (4 cols) */}
        <aside className="lg:col-span-4 space-y-6 lg:space-y-8">
          {/* Summary Card */}
          <Card className="p-6 lg:p-8 rounded-2xl">
            <h3 className="text-2xl lg:text-3xl leading-snug font-bold text-white mb-6 m-0">Profile Summary</h3>

            <div className="space-y-4">
              <div>
                <div className="text-label text-gray-400 mb-1">Name</div>
                <div className="text-body text-white font-semibold">{formData.name || '–'}</div>
              </div>

              <div>
                <div className="text-label text-gray-400 mb-1">Age & Gender</div>
                <div className="text-body text-white font-semibold">
                  {formData.age ? `${formData.age} yrs, ${formData.gender}` : '–'}
                </div>
              </div>

              <div className="pt-4 border-t border-white/10">
                <div className="text-label text-gray-400 mb-1">BMI</div>
                <div className="text-body text-white font-semibold">{bmi > 0 ? bmi.toFixed(1) : '–'}</div>
              </div>

              <div>
                <div className="text-label text-gray-400 mb-1">BMR (kcal/day)</div>
                <div className="text-body text-white font-semibold">{bmr > 0 ? bmr.toLocaleString() : '–'}</div>
              </div>

              <div className="pt-4 border-t border-white/10">
                <div className="text-label text-gray-400 mb-1">TDEE</div>
                <div className="text-body text-white font-semibold">{tdee > 0 ? tdee.toLocaleString() : '–'} kcal</div>
              </div>

              <div>
                <div className="text-label text-gray-400 mb-1">Weight Goal</div>
                <div className="text-body text-white font-semibold">
                  {formData.currentWeight && formData.targetWeight
                    ? `${Math.abs(parseFloat(formData.targetWeight) - parseFloat(formData.currentWeight)).toFixed(1)} kg to go`
                    : '–'}
                </div>
              </div>
            </div>
          </Card>

          {/* Tips Card */}
          <Card className="p-6 lg:p-8 rounded-2xl bg-purple-500/10 border-purple-500/20">
            <h3 className="text-2xl lg:text-3xl leading-snug font-bold text-white mb-4 m-0">Pro Tips</h3>
            <ul className="space-y-3 text-label text-gray-400">
              <li className="flex gap-2">
                <span className="text-purple-400 flex-shrink-0">✓</span>
                <span>Accurate measurements help personalize your plan</span>
              </li>
              <li className="flex gap-2">
                <span className="text-purple-400 flex-shrink-0">✓</span>
                <span>Activity level affects your calorie needs</span>
              </li>
              <li className="flex gap-2">
                <span className="text-purple-400 flex-shrink-0">✓</span>
                <span>You can update your info anytime in Profile</span>
              </li>
            </ul>
          </Card>
        </aside>
      </form>

      {/* Action buttons */}
      <div className="flex gap-4 justify-end mt-8 lg:mt-12">
        <Button variant="ghost" onClick={() => navigate('/')}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : 'Save & Continue'}
        </Button>
      </div>
    </Layout>
  );
}
