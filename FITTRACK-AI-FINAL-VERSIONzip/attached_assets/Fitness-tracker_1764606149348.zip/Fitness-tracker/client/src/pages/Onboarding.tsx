import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, ArrowLeft, User, Ruler, Scale, Activity } from 'lucide-react';
import { useGoal } from '../contexts/GoalContext';
import { useUser } from '../contexts/UserContext';
import { Button } from '../components/shared/Button';
import { Card } from '../components/shared/Card';
import { BackLink } from '../components/shared/BackLink';
import type { UserProfile, ActivityLevel } from '../types';

const activityLevels: { value: ActivityLevel; label: string; description: string }[] = [
  { value: 'sedentary', label: 'Sedentary', description: 'Little or no exercise' },
  { value: 'light', label: 'Lightly Active', description: 'Light exercise 1-3 days/week' },
  { value: 'moderate', label: 'Moderately Active', description: 'Moderate exercise 3-5 days/week' },
  { value: 'active', label: 'Active', description: 'Hard exercise 6-7 days/week' },
  { value: 'very-active', label: 'Very Active', description: 'Very hard exercise daily' },
];

export function Onboarding() {
  const navigate = useNavigate();
  const { currentGoal } = useGoal();
  const { setProfile } = useUser();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: 'male' as 'male' | 'female',
    height: '',
    currentWeight: '',
    targetWeight: '',
    activityLevel: 'moderate' as ActivityLevel,
  });

  const totalSteps = 4;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      const profile: UserProfile = {
        id: `user-${Date.now()}`,
        name: formData.name,
        email: '',
        age: parseInt(formData.age),
        gender: formData.gender,
        height: parseFloat(formData.height),
        currentWeight: parseFloat(formData.currentWeight),
        targetWeight: parseFloat(formData.targetWeight),
        activityLevel: formData.activityLevel,
        goal: currentGoal,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setProfile(profile);
      navigate('/dashboard');
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      navigate('/');
    }
  };

  const isStepValid = () => {
    switch (step) {
      case 1:
        return formData.name.trim() !== '' && formData.age !== '' && parseInt(formData.age) > 0;
      case 2:
        return formData.height !== '' && parseFloat(formData.height) > 0;
      case 3:
        return formData.currentWeight !== '' && formData.targetWeight !== '' &&
               parseFloat(formData.currentWeight) > 0 && parseFloat(formData.targetWeight) > 0;
      case 4:
        return true;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex items-center gap-3">
          <BackLink fallback="/" />
        </div>
        <div className="text-center mb-8">
          <h1 className="text-page-title text-white mb-3">Set Up Your Profile</h1>
          <p className="text-label text-gray-400">Step {step} of {totalSteps}</p>
        </div>

        <div className="flex gap-2 mb-8">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className={`flex-1 h-2 rounded-full ${
                i < step ? 'bg-purple-500' : 'bg-white/10'
              }`}
            />
          ))}
        </div>

        <Card className="p-8 mb-8">
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <User className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h2 className="text-card-title text-white">Basic Info</h2>
                  <p className="text-label text-gray-400">Tell us about yourself</p>
                </div>
              </div>
              
              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Your Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter your name"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Age</label>
                <input
                  type="number"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  placeholder="Enter your age"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Gender</label>
                <div className="grid grid-cols-2 gap-3">
                  {(['male', 'female'] as const).map((gender) => (
                    <button
                      key={gender}
                      type="button"
                      onClick={() => setFormData({ ...formData, gender })}
                      className={`py-3 rounded-xl border transition-all text-body font-medium ${
                        formData.gender === gender
                          ? 'bg-purple-500/20 border-purple-500 text-purple-400'
                          : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/30'
                      }`}
                    >
                      {gender.charAt(0).toUpperCase() + gender.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <Ruler className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h2 className="text-card-title text-white">Your Height</h2>
                  <p className="text-label text-gray-400">We'll use this to calculate your needs</p>
                </div>
              </div>

              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Height (cm)</label>
                <input
                  type="number"
                  value={formData.height}
                  onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                  placeholder="Enter your height"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <Scale className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h2 className="text-card-title text-white">Your Weight</h2>
                  <p className="text-label text-gray-400">Current and target weight</p>
                </div>
              </div>

              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Current Weight (kg)</label>
                <input
                  type="number"
                  value={formData.currentWeight}
                  onChange={(e) => setFormData({ ...formData, currentWeight: e.target.value })}
                  placeholder="Enter your current weight"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-label text-gray-400 mb-3 font-medium">Target Weight (kg)</label>
                <input
                  type="number"
                  value={formData.targetWeight}
                  onChange={(e) => setFormData({ ...formData, targetWeight: e.target.value })}
                  placeholder="Enter your target weight"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <Activity className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h2 className="text-card-title text-white">Activity Level</h2>
                  <p className="text-label text-gray-400">Choose your typical activity</p>
                </div>
              </div>

              <div className="space-y-3">
                {activityLevels.map((level) => (
                  <button
                    key={level.value}
                    type="button"
                    onClick={() => setFormData({ ...formData, activityLevel: level.value })}
                    className={`w-full p-4 rounded-xl border transition-all text-left ${
                      formData.activityLevel === level.value
                        ? 'bg-purple-500/20 border-purple-500'
                        : 'bg-white/5 border-white/10 hover:border-white/30'
                    }`}
                  >
                    <div className="font-semibold text-white text-body">{level.label}</div>
                    <div className="text-label text-gray-400">{level.description}</div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </Card>

        <div className="flex gap-4">
          <Button variant="ghost" onClick={handleBack} className="flex-1 py-3">
            <ArrowLeft className="w-5 h-5" />
            {step === 1 ? 'Cancel' : 'Back'}
          </Button>
          <Button onClick={handleNext} disabled={!isStepValid()} className="flex-1 py-3">
            {step === totalSteps ? 'Complete' : 'Next'}
            <ArrowRight className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
