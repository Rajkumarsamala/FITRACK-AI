import { useNavigate } from 'react-router-dom';
import { Flame, Dumbbell, ArrowRight, Zap, Target, TrendingUp, Brain } from 'lucide-react';
import { useGoal } from '../contexts/GoalContext';
import { useUser } from '../contexts/UserContext';
import { Button } from '../components/shared/Button';
import { Card } from '../components/shared/Card';

export function Landing() {
  const navigate = useNavigate();
  const { setGoal, goals } = useGoal();
  const { isOnboarded } = useUser();

  const handleGoalSelect = (goalId: 'lose-weight' | 'gain-weight') => {
    setGoal(goalId);
    if (isOnboarded) {
      navigate('/dashboard');
    } else {
      navigate('/onboarding');
    }
  };

  const features = [
    { icon: Target, title: 'Personalized Plans', description: 'Custom nutrition and workout plans tailored to your goals' },
    { icon: TrendingUp, title: 'Progress Tracking', description: 'Track your journey with detailed analytics and insights' },
    { icon: Brain, title: 'AI-Powered Tips', description: 'Smart recommendations that adapt to your progress' },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <header className="glass fixed top-0 left-0 right-0 z-50">
        <div className="container-responsive py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold gradient-text">FitTrack AI</span>
          </div>
          {isOnboarded && (
            <Button variant="outline" size="sm" onClick={() => navigate('/dashboard')}>
              Dashboard
            </Button>
          )}
        </div>
      </header>

      <main className="flex-1 pt-32 pb-20">
        <section className="container-responsive mb-32">
          <div className="lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="lg:col-span-8 lg:col-start-3 text-center">
              <div className="inline-flex items-center gap-3 glass px-5 py-3 rounded-full mb-10">
                <Zap className="w-4 h-4 text-purple-400" />
                <span className="text-label text-gray-300 font-medium">AI-Powered Fitness Tracking</span>
              </div>
              
              <h1 className="text-5xl lg:text-6xl font-bold mb-6 text-white leading-tight">
                <span className="gradient-text">Transform</span>
                <br />
                Your Fitness
              </h1>
              
              <p className="text-body text-gray-400 mb-16 leading-relaxed">
                AI-powered insights, personalized plans, and smart tracking—all completely free
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto mb-28">
            {goals.map((goal) => {
              const Icon = goal.id === 'lose-weight' ? Flame : Dumbbell;
              const bgColor = goal.id === 'lose-weight' 
                ? 'from-orange-500/20 to-red-500/20 border-orange-500/30 hover:border-orange-400'
                : 'from-green-500/20 to-emerald-500/20 border-green-500/30 hover:border-green-400';
              const iconColor = goal.id === 'lose-weight' ? 'text-orange-400' : 'text-green-400';
              
              return (
                <Card
                  key={goal.id}
                  variant="gradient"
                  className={`bg-gradient-to-br ${bgColor} cursor-pointer group h-full`}
                  onClick={() => handleGoalSelect(goal.id)}
                >
                  <div className="flex flex-col items-center text-center">
                    <div className={`w-20 h-20 rounded-2xl bg-white/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                      <Icon className={`w-10 h-10 ${iconColor}`} />
                    </div>
                    <h3 className="text-card-title text-white mb-3">{goal.label}</h3>
                    <p className="text-body text-gray-400 mb-6 leading-relaxed">{goal.description}</p>
                    <div className={`flex items-center gap-2 ${iconColor} font-semibold`}>
                      <span>Get Started</span>
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </section>

        <section id="features" className="container-responsive">
          <div className="feature-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch content-start">
            {features.map((feature) => (
              <Card key={feature.title} className="feature-card h-full m-0 p-8 flex flex-col justify-between text-center rounded-2xl">
                <div className="relative mb-4">
                  <div className="w-16 h-16 rounded-2xl bg-purple-500/20 flex items-center justify-center mx-auto">
                    <feature.icon className="w-8 h-8 text-purple-400" />
                  </div>
                </div>
                <div>
                  <h2 className="text-section-title text-white mb-3">{feature.title}</h2>
                  <p className="text-body text-gray-400 leading-relaxed">{feature.description}</p>
                </div>
              </Card>
            ))}
          </div>
        </section>

        <section id="cta" className="container-responsive mt-16 lg:mt-20">
          <div className="lg:grid lg:grid-cols-12">
            <Card variant="glow" className="lg:col-span-8 lg:col-start-3 py-16">
              <h2 className="text-section-title text-white mb-6 text-center">Ready to Start?</h2>
              <p className="text-body text-gray-400 mb-10 text-center leading-relaxed">Choose your fitness goal and begin your transformation today</p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Button onClick={() => handleGoalSelect('lose-weight')} className="gap-3">
                  <Flame className="w-6 h-6" />
                  Lose Weight
                </Button>
                <Button variant="secondary" onClick={() => handleGoalSelect('gain-weight')} className="gap-3">
                  <Dumbbell className="w-6 h-6" />
                  Gain Weight
                </Button>
              </div>
            </Card>
          </div>
        </section>
      </main>

      <footer className="glass py-8">
        <div className="container-responsive text-center text-gray-400 text-label">
          <p>Powered by AI · Free Forever · No Account Required</p>
        </div>
      </footer>
    </div>
  );
}
