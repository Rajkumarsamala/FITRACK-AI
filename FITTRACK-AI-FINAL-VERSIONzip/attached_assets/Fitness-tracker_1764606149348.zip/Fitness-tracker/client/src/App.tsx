import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { GoalProvider } from './contexts/GoalContext';
import { UserProvider, useUser } from './contexts/UserContext';
import { Landing } from './pages/Landing';
import { OnboardingSinglePage } from './pages/OnboardingSinglePage';
import { Dashboard } from './pages/Dashboard';
import { Nutrition } from './pages/Nutrition';
import { Workouts } from './pages/Workouts';
import { Progress } from './pages/Progress';
import { Tips } from './pages/Tips';
import { Profile } from './pages/Profile';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isCurrentGoalOnboarded } = useUser();
  
  if (!isCurrentGoalOnboarded) {
    return <Navigate to="/onboarding" replace />;
  }
  
  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/onboarding" element={<OnboardingSinglePage />} />
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/nutrition" element={<ProtectedRoute><Nutrition /></ProtectedRoute>} />
      <Route path="/workouts" element={<ProtectedRoute><Workouts /></ProtectedRoute>} />
      <Route path="/progress" element={<ProtectedRoute><Progress /></ProtectedRoute>} />
      <Route path="/tips" element={<ProtectedRoute><Tips /></ProtectedRoute>} />
      <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <BrowserRouter>
      <GoalProvider>
        <UserProvider>
          <AppRoutes />
        </UserProvider>
      </GoalProvider>
    </BrowserRouter>
  );
}

export default App;
