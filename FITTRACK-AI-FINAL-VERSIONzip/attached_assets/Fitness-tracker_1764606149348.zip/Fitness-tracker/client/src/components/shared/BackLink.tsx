import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface BackLinkProps {
  fallback?: string;
}

export function BackLink({ fallback = '/dashboard' }: BackLinkProps) {
  const navigate = useNavigate();
  
  const handleClick = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate(fallback);
    }
  };

  return (
    <button
      onClick={handleClick}
      className="back-link flex items-center gap-2 px-3 py-2 rounded-lg border border-purple-500/25 hover:bg-purple-500/10 transition-colors text-sm font-medium text-gray-300 hover:text-white"
      aria-label="Go back"
      title="Go back (or Dashboard if history unavailable)"
    >
      <ArrowLeft className="w-4 h-4" />
      Back
    </button>
  );
}
