import { Link, useLocation } from 'react-router-dom';
import { Home, Utensils, Dumbbell, LineChart, Lightbulb, User, Zap } from 'lucide-react';
import { useGoal } from '../../contexts/GoalContext';

const navItems = [
  { path: '/dashboard', icon: Home, label: 'Dashboard' },
  { path: '/nutrition', icon: Utensils, label: 'Nutrition' },
  { path: '/workouts', icon: Dumbbell, label: 'Workouts' },
  { path: '/progress', icon: LineChart, label: 'Progress' },
  { path: '/tips', icon: Lightbulb, label: 'AI Tips' },
  { path: '/profile', icon: User, label: 'Profile' },
];

export function Navigation() {
  const location = useLocation();
  const { goalConfig } = useGoal();

  return (
    <nav className="fixed bottom-0 left-0 right-0 md:top-0 md:bottom-auto glass z-50">
      <div className="container-responsive">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="hidden md:flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">FitTrack AI</span>
          </Link>

          <div className="flex items-center justify-around md:justify-end gap-1 md:gap-2 w-full md:w-auto">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex flex-col md:flex-row items-center gap-1 px-3 py-2 rounded-lg transition-all ${
                    isActive
                      ? 'bg-purple-500/20 text-purple-400'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-xs md:text-sm">{item.label}</span>
                </Link>
              );
            })}
          </div>

          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full glass">
            <span className="text-lg">{goalConfig.icon}</span>
            <span className="text-sm text-gray-300">{goalConfig.id === 'lose-weight' ? 'Lose' : 'Gain'}</span>
          </div>
        </div>
      </div>
    </nav>
  );
}
