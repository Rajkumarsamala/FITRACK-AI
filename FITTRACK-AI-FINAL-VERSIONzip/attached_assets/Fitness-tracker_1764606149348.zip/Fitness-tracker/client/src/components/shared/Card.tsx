import type { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  variant?: 'default' | 'gradient' | 'glow';
}

export function Card({ children, className = '', onClick, variant = 'default' }: CardProps) {
  const baseClasses = 'rounded-2xl p-8 transition-all';
  
  const variantClasses = {
    default: 'glass',
    gradient: 'gradient-border',
    glow: 'glass card-glow hover:shadow-purple-500/20',
  };

  return (
    <div
      className={`${baseClasses} ${variantClasses[variant]} ${className} ${onClick ? 'cursor-pointer hover:scale-[1.02]' : ''}`}
      onClick={onClick}
    >
      {children}
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  color?: string;
}

export function StatCard({ title, value, subtitle, icon, trend, color = 'purple' }: StatCardProps) {
  const colorClasses: Record<string, string> = {
    purple: 'from-purple-500 to-purple-700',
    orange: 'from-orange-500 to-orange-700',
    green: 'from-green-500 to-green-700',
    blue: 'from-blue-500 to-blue-700',
  };

  return (
    <Card className="relative overflow-hidden">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <p className="text-gray-400 text-sm mb-2">{title}</p>
          <p className="text-3xl font-bold text-white mb-1">{value}</p>
          {subtitle && (
            <p className={`text-sm ${
              trend === 'up' ? 'text-green-400' : 
              trend === 'down' ? 'text-red-400' : 
              'text-gray-400'
            }`}>
              {trend === 'up' && '↑ '}
              {trend === 'down' && '↓ '}
              {subtitle}
            </p>
          )}
        </div>
        {icon && (
          <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${colorClasses[color]} flex items-center justify-center flex-shrink-0`}>
            {icon}
          </div>
        )}
      </div>
    </Card>
  );
}
