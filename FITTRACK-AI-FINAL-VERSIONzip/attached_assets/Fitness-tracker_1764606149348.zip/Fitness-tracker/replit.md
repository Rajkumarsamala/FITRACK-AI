# FitTrack AI - Dual-Goal Fitness Platform

## Overview
A comprehensive fitness tracking web application supporting both weight loss and weight gain goals. Users can track nutrition, follow personalized workout plans, monitor progress, and receive AI-powered tips tailored to their specific fitness objectives.

## Recent Changes
- **December 2024**: Complete rebuild from imported site (original had only compiled assets)
- Fixed Tailwind CSS v4 PostCSS configuration (requires @tailwindcss/postcss)
- Implemented goal-aware architecture with shared components
- Added all core features: nutrition calculator, workout library, progress tracking, AI tips
- **Implemented complete responsive layout system**:
  - Fluid type scale with responsive typography (6 levels using CSS clamp functions)
  - Semantic heading hierarchy (H1: 32-48px, H2: 26-36px, H3: 22-28px)
  - CSS spacing scale variables (--space-1 to --space-6: 8px to 48px)
  - Max-width 1200px container with adaptive responsive padding
  - 12-column grid on desktop (≥1024px) with consistent gaps
- **Production build complete**: All TypeScript errors fixed, build optimized, ready to publish

## Tech Stack
- **Frontend**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS v4 with custom dark purple gradient theme
- **State Management**: React Context (GoalContext, UserContext)
- **Storage**: localStorage for user data persistence (no backend required)
- **Deployment**: Static deployment (Vite build → dist folder)

## Project Architecture

```
client/
├── src/
│   ├── components/
│   │   ├── shared/         # Reusable UI components (GoalToggle, Cards, etc.)
│   │   └── layout/         # Layout components (Navigation, Footer)
│   ├── contexts/
│   │   ├── GoalContext.tsx # Goal state (lose/gain weight)
│   │   └── UserContext.tsx # User profile and progress data
│   ├── data/
│   │   ├── workouts.ts     # Workout plans for both goals
│   │   └── meals.ts        # Meal plans for both goals
│   ├── pages/
│   │   ├── Landing.tsx     # Goal selection landing page
│   │   ├── Onboarding.tsx  # User profile setup
│   │   ├── Dashboard.tsx   # Main dashboard with stats
│   │   ├── Nutrition.tsx   # Calorie/macro calculator
│   │   ├── Workouts.tsx    # Workout library and plans
│   │   ├── Progress.tsx    # Progress tracking with charts
│   │   ├── AITips.tsx      # AI-powered recommendations
│   │   └── Profile.tsx     # User profile management
│   ├── services/
│   │   └── calculator.ts   # BMR, TDEE, calorie calculations
│   ├── index.css           # Global styles with spacing scale and fluid typography
│   └── App.tsx             # Main app with routing
├── postcss.config.js       # PostCSS with @tailwindcss/postcss
├── vite.config.ts          # Vite config (port 5000, host 0.0.0.0)
└── dist/                   # Production build (ready to deploy)
```

## Key Features
1. **Dual Goal Support**: "Lose Weight & Get Fit" and "Gain Weight & Build Muscle"
2. **Nutrition Calculator**: Personalized calorie targets (deficit or surplus based on goal)
3. **Workout Library**: Goal-specific workout plans (HIIT/cardio vs. strength/hypertrophy)
4. **Progress Tracking**: Weight, measurements, and workout history with visual charts
5. **AI Tips**: Context-aware recommendations based on user's goal and progress
6. **Profile Management**: Store and update user information

## Responsive Layout System
- **Container**: max-width 1200px, centered, padding clamps between 16-32px responsive to viewport
- **Spacing Scale**: CSS variables --space-1 through --space-6 (8px to 48px)
- **Typography**: Fluid type scale using clamp() for responsive sizing
- **Grid**: 12-column grid on desktop with consistent gaps (gap-6 mobile, lg:gap-8 desktop)
- **Spacing**: Section gaps use --space-5 (32px), card gaps use --space-4 (24px), internal padding uses --space-3 (16px)
- **Tested Breakpoints**: Responsive across 360px mobile, 1024px tablet, 1280px/1440px desktop

## Development
- Server runs on port 5000 (required for Replit webview)
- All hosts allowed in Vite config for Replit proxy compatibility
- Tailwind CSS v4 uses `@import "tailwindcss"` syntax (not @tailwind directives)
- TypeScript strict mode enabled
- Zero compilation errors in production build

## Production Deployment
- **Status**: ✅ Ready to publish
- **Build Command**: `npm run build`
- **Output Directory**: `dist/`
- **Deployment Type**: Static (Vite SPA)
- **Build Size**: 35.66 KB CSS (gzipped), 307.33 KB JS (gzipped)

## User Preferences
- Dark theme with purple gradient aesthetic
- No account required (localStorage-based)
- Free forever model
- Clean, modern, premium design
- Fully responsive (mobile-first, optimized for all screen sizes)
